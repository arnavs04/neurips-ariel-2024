=======
Credits
=======

Development Lead
----------------

* Piotr Szymański <niedakh@gmail.com>

Contributors
------------

* `dangercrow <https://github.com/dangercrow>`_
* `Mark Bell  <https://github.com/MarkCBell>`_
